<template>
  <div class="form-container">
    <PostEditForm></PostEditForm>
  </div>
</template>

<script>
import PostEditForm from '@/components/Posts/PostEditForm.vue';
export default {
  components: {
    PostEditForm,
  },
};
</script>

<style></style>
