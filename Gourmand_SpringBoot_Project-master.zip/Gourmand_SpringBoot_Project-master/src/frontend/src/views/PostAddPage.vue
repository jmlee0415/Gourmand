<template>
  <div class="form-container">
    <PostAddForm></PostAddForm>
  </div>
</template>

<script>
import PostAddForm from '@/components/Posts/PostAddForm.vue';
export default {
  components: {
    PostAddForm,
  },
};
</script>

<style></style>
