package io.gourmand.dao;

import org.springframework.data.repository.CrudRepository;

import io.gourmand.domain.ResImg;

public interface ResImgRepository extends CrudRepository<ResImg, Long> {
	
}

